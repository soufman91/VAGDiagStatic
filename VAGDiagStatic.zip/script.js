// Base embarquée (fallback)
const DEFAULT_CODES = {
  "17965": {
    "systeme": "Turbo",
    "libelle": "Charge Pressure Control: Positive Deviation",
    "description": "Surpression turbo détectée.",
    "commentaires": [
      "Wastegate grippée",
      "N75 défaillante"
    ]
  },
  "01314": {
    "systeme": "Calculateur moteur",
    "libelle": "ECM – No Communication",
    "description": "Pas de communication avec le calculateur moteur.",
    "commentaires": [
      "Faisceau CAN",
      "Alimentation calculateur"
    ]
  }
};

let CODES = DEFAULT_CODES;

// Tente de charger vag_codes.json si on est servi via HTTP
fetch('vag_codes.json')
  .then(r => {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  })
  .then(data => {
    CODES = data;
    console.log('Codes VAG chargés depuis vag_codes.json');
  })
  .catch(err => {
    console.warn('Impossible de charger vag_codes.json, utilisation des codes par défaut intégrés.', err);
  });

function normalizeCode(raw) {
  let code = raw.trim().toUpperCase();
  if (!code) return code;

  if (code.length === 5 && code.startsWith('P') && /^\d{4}$/.test(code.slice(1))) {
    return code;
  }
  if (/^\d+$/.test(code)) {
    code = code.replace(/^0+/, '');
    return code || '0';
  }
  return code;
}

function getCandidates(raw) {
  const cleaned = normalizeCode(raw);
  const candidates = [];
  const seen = new Set();

  if (cleaned) {
    candidates.push(cleaned);
    if (/^\d+$/.test(cleaned)) {
      candidates.push(cleaned.padStart(5, '0'));
    }
  }

  const rawUpper = raw.trim().toUpperCase();
  if (rawUpper) {
    candidates.push(rawUpper);
  }

  const final = [];
  for (const c of candidates) {
    if (!seen.has(c)) {
      seen.add(c);
      final.push(c);
    }
  }
  return final;
}

function searchCode(raw) {
  if (!raw.trim()) {
    return { result: null, message: "Saisis un code avant de lancer la recherche." };
  }
  const candidates = getCandidates(raw);
  for (const c of candidates) {
    if (CODES[c]) {
      return { result: CODES[c], message: null };
    }
  }
  return {
    result: null,
    message: `Code « ${raw.trim().toUpperCase()} » non trouvé dans la base. Ajoute-le dans vag_codes.json.`
  };
}

function clearResult() {
  const msgEl = document.getElementById('message');
  const card = document.getElementById('result');
  msgEl.style.display = 'none';
  card.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('diag-form');
  const input = document.getElementById('code');
  const msgEl = document.getElementById('message');
  const card = document.getElementById('result');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const { result, message } = searchCode(input.value);

    msgEl.style.display = 'none';
    card.style.display = 'none';

    if (message) {
      msgEl.textContent = message;
      msgEl.style.display = 'block';
      return;
    }

    if (result) {
      document.getElementById('res-systeme').textContent = result.systeme || '';
      document.getElementById('res-libelle').textContent = result.libelle || '';

      const descBlock = document.getElementById('res-description-block');
      if (result.description) {
        document.getElementById('res-description').textContent = result.description;
        descBlock.style.display = 'block';
      } else {
        descBlock.style.display = 'none';
      }

      const comBlock = document.getElementById('res-commentaires-block');
      const ul = document.getElementById('res-commentaires');
      ul.innerHTML = '';
      if (Array.isArray(result.commentaires) && result.commentaires.length > 0) {
        result.commentaires.forEach(c => {
          const li = document.createElement('li');
          li.textContent = c;
          ul.appendChild(li);
        });
        comBlock.style.display = 'block';
      } else {
        comBlock.style.display = 'none';
      }

      card.style.display = 'block';
    }
  });

  document.getElementById('btn-clear').addEventListener('click', () => {
    input.value = '';
    input.focus();
    clearResult();
  });
});
